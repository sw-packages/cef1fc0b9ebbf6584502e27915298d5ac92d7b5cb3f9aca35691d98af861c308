//              -- request_service_fwd.hpp --
//
//            Copyright (c) Darren Garvey 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
//
////////////////////////////////////////////////////////////////
#ifndef CGI_REQUEST_SERVICE_FWD_HPP_INCLUDED
#define CGI_REQUEST_SERVICE_FWD_HPP_INCLUDED


BOOST_CGI_NAMESPACE_BEGIN

  /// The generic service class for basic_request<>s
  /**
   * Note: If the protocol is an asynchronous protocol, which means it requires
   * access to a boost::asio::io_service instance, then this class becomes a
   * model of the Service concept (**LINK**) and must only use the constructor
   * which takes a ProtocolService (**LINK**). If the protocol isn't async then
   * the class can be used without a ProtocolService.
   */
  template<typename Protocol>
  class request_service;

BOOST_CGI_NAMESPACE_END

#endif // CGI_REQUEST_SERVICE_FWD_HPP_INCLUDED
